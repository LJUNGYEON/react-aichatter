function Dropdown() {

  return (
    <>
      <li>마이페이지</li>
      <li>로그아웃</li>
    </>
  );
}

export default Dropdown;