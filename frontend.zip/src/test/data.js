let data=[
    {
      id : 0,
      title : "ai test 첫번째",
      content : "Born in France",
      regdate : "20230710151500"
    },

    {
      id : 1,
      title : "ai test 두번째",
      content : "Born in Seoul",
      regdate : "20230708110000"
    },

    {
      id : 2,
      title : "ai test 3번째",
      content : "ABCEFSFW",
      regdate : "20230711181518"
    }
  ]

export default data;
