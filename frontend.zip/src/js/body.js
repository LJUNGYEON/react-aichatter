import React, {useEffect, useState} from 'react';

import bg from '../img/aiChatter2.png';
import '../css/main.css';

import {Button,Navbar,Container, Nav, Row, Col} from 'react-bootstrap';

function Body(){
    return(
        <div className="main">
           <div className="main-img">
             <p style={{paddingTop:"25%"}}>나만의 어시스턴트 스마트한 경험</p>
             <div  className="main-bg" style={{backgroundImage:'url('+bg+')'}}></div>
           </div>
           <div className="main-select">
                <p>나만의 어시스턴트 스마트한 경험</p>
           </div>
           <div className="main-ex">
               <p>나만의 어시스턴트 스마트한 경험</p>
          </div>
           <div className="main-chat">
             <p>나만의 어시스턴트 스마트한 경험</p>
        </div>
        </div>
    )
}
export default Body;

